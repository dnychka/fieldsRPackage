#
# fields  is a package for analysis of spatial data written for
# the R software environment.
# Copyright (C) 2024 Colorado School of Mines
# 1500 Illinois St., Golden, CO 80401
# Contact: Douglas Nychka,  douglasnychka@gmail.com,
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2
##END HEADER

"predictSurfaceSE"<- function( object,...){
  UseMethod("predictSurfaceSE")
}

"predictSurfaceSE.default" <- 
  function(object, grid.list = NULL, 
           extrap = FALSE, chull.mask = NA, nx = 80, ny = 80,
           xy = c(1,2),  verbose = FALSE,
           XMatGrid=NULL, just.fixed=FALSE,  ...) {
    
    # create a default grid if it is not passed    
    if (is.null(grid.list)) {
      # NOTE: 
      # without grid.list
      # default is 80X80 grid on first two variables
      # rest are set to median value of the x's
      grid.list <- fields.x.to.grid(object$x, nx = nx, ny = ny, 
                                    xy = xy)
    }
    # do some checks on XMatgrid if passed and also reshape as a matrix
    # rows index grid locations and columns  are the covariates
    # (as XMat in predict).
    # if XMatGrid is NULL just returns that back
    
    XMat<- unrollXMatGrid( grid.list, XMatGrid) 
    
    # Convert grid.list to the full set of locations
    xg <- make.surface.grid(grid.list)
    # NOTE: the predict function called will need to do some internal  the checks
    # whether the evaluation of a large number of grid points (xg)  makes sense.
    if( verbose){
      print( dim( xg))
      print( dim( XMat))
    }
#    
# Next call is fragile as it assumes the predictSE method includes
# a  XMat argument  (even if it will often just be NULL )
      out0<- predictSE(object, xg, XMat=XMat, ...)
# coerce back into image format      
      out <-  as.surface( xg, out0)
    #
    # if extrapolate is FALSE set all values outside convex hull to NA
    if (!extrap) {
        if( is.null( object$x)){
          stop("need and x matrix in object")
        }
        if (is.na(chull.mask)) {
            chull.mask <- unique.matrix(object$x[, xy])
        }
        out$z[!in.poly(xg[, xy], xp = chull.mask, convex.hull = TRUE)] <- NA
    }
    #
    return(out)
}




